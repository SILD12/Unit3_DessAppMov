package com.example.navigationcomponent;

import android.gesture.Gesture;
import android.gesture.GestureOverlayView;

public interface cocfig {
    void onGesturePerformed(GestureOverlayView overlay, Gesture gesture);
}
